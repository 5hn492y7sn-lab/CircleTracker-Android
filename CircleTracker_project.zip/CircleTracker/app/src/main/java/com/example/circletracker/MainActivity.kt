package com.example.circletracker

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var projectionManager: MediaProjectionManager
    private val screenCaptureRequestCode = 1000
    private val overlayPermissionRequestCode = 1001

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        projectionManager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager

        val etRadius = findViewById<EditText>(R.id.etRadius)
        val etAlpha = findViewById<EditText>(R.id.etAlpha)
        val etRegionWidth = findViewById<EditText>(R.id.etRegionWidth)
        val etRegionHeight = findViewById<EditText>(R.id.etRegionHeight)
        val etSensitivity = findViewById<EditText>(R.id.etSensitivity)
        val btnToggleBox = findViewById<Button>(R.id.btnToggleBox)

        btnToggleBox.setOnClickListener {
            OverlayService.showBox = !OverlayService.showBox
            btnToggleBox.text = if (OverlayService.showBox)
                "検出枠の線をみる (ON)" else "検出枠の線をみる (OFF)"
        }

        findViewById<Button>(R.id.btnStart).setOnClickListener {
            OverlayService.radius = etRadius.text.toString().toFloatOrNull() ?: 100f
            OverlayService.alpha = (etAlpha.text.toString().toIntOrNull() ?: 51).coerceIn(0, 255)
            OverlayService.regionWidth = etRegionWidth.text.toString().toIntOrNull() ?: 300
            OverlayService.regionHeight = etRegionHeight.text.toString().toIntOrNull() ?: 300
            OverlayService.sensitivity = etSensitivity.text.toString().toDoubleOrNull() ?: 100.0
            checkOverlayPermissionAndStart()
        }

        findViewById<Button>(R.id.btnStop).setOnClickListener {
            stopService(Intent(this, OverlayService::class.java))
            Toast.makeText(this, "検出を停止しました", Toast.LENGTH_SHORT).show()
        }
    }

    private fun checkOverlayPermissionAndStart() {
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivityForResult(intent, overlayPermissionRequestCode)
        } else {
            startScreenCapture()
        }
    }

    private fun startScreenCapture() {
        startActivityForResult(
            projectionManager.createScreenCaptureIntent(),
            screenCaptureRequestCode
        )
    }

    @Deprecated("Deprecated by Android; retained for compatibility with this sample")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            screenCaptureRequestCode -> {
                if (resultCode == Activity.RESULT_OK && data != null) {
                    val serviceIntent = Intent(this, OverlayService::class.java).apply {
                        putExtra("resultCode", resultCode)
                        putExtra("data", data)
                    }
                    startForegroundService(serviceIntent)
                    Toast.makeText(this, "検出を開始しました", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "画面キャプチャの許可が必要です", Toast.LENGTH_SHORT).show()
                }
            }
            overlayPermissionRequestCode -> {
                if (Settings.canDrawOverlays(this)) startScreenCapture()
                else Toast.makeText(this, "オーバーレイ権限が必要です", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
