package com.example.circletracker

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.View

class OverlayView(context: Context) : View(context) {
    @Volatile private var circleX = -1f
    @Volatile private var circleY = -1f

    var overlayRadius = 100f
    var overlayAlpha = 51
    var showBox = false
    var boxWidth = 300
    var boxHeight = 300

    private val paintCircle = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.RED
        style = Paint.Style.FILL
    }
    private val paintBox = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.MAGENTA
        style = Paint.Style.STROKE
        strokeWidth = 4f
    }

    fun updatePosition(x: Float, y: Float) {
        circleX = x
        circleY = y
        postInvalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (showBox) {
            val cx = width / 2f
            val cy = height / 2f
            canvas.drawRect(
                cx - boxWidth / 2f, cy - boxHeight / 2f,
                cx + boxWidth / 2f, cy + boxHeight / 2f, paintBox
            )
        }
        if (circleX >= 0f && circleY >= 0f) {
            paintCircle.alpha = overlayAlpha.coerceIn(0, 255)
            canvas.drawCircle(circleX, circleY, overlayRadius.coerceAtLeast(1f), paintCircle)
        }
    }
}
