package com.example.circletracker

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import org.opencv.android.OpenCVLoader
import org.opencv.core.Core
import org.opencv.core.CvType
import org.opencv.core.Mat
import org.opencv.core.MatOfPoint
import org.opencv.core.MatOfPoint2f
import org.opencv.core.Point
import org.opencv.core.Rect
import org.opencv.core.Scalar
import org.opencv.core.Size
import org.opencv.imgproc.Imgproc
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.hypot

class OverlayService : Service() {
    companion object {
        @Volatile var radius = 100f
        @Volatile var alpha = 51
        @Volatile var regionWidth = 300
        @Volatile var regionHeight = 300
        @Volatile var sensitivity = 100.0
        @Volatile var showBox = false
    }

    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private lateinit var windowManager: WindowManager
    private lateinit var overlayView: OverlayView
    private val running = AtomicBoolean(false)
    private var worker: Thread? = null
    private var screenWidth = 1
    private var screenHeight = 1
    private var screenDensity = 1
    private var lastX = -1f
    private var lastY = -1f

    override fun onCreate() {
        super.onCreate()
        if (!OpenCVLoader.initDebug()) {
            stopSelf()
            return
        }
        createNotificationChannel()
        startForeground(1, createNotification())
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        overlayView = OverlayView(this).apply { applySettings() }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }
        windowManager.addView(overlayView, params)
    }

    private fun OverlayView.applySettings() {
        overlayRadius = radius
        overlayAlpha = alpha
        showBox = Companion.showBox
        boxWidth = regionWidth
        boxHeight = regionHeight
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        overlayView.applySettings()
        overlayView.invalidate()
        val resultCode = intent?.getIntExtra("resultCode", 0) ?: 0
        @Suppress("DEPRECATION")
        val data = if (Build.VERSION.SDK_INT >= 33) {
            intent?.getParcelableExtra("data", Intent::class.java)
        } else {
            intent?.getParcelableExtra("data")
        }
        if (resultCode != 0 && data != null && mediaProjection == null) {
            val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            mediaProjection = manager.getMediaProjection(resultCode, data)
            startCapture()
        }
        return START_NOT_STICKY
    }

    private fun startCapture() {
        val metrics = resources.displayMetrics
        screenWidth = metrics.widthPixels.coerceAtLeast(1)
        screenHeight = metrics.heightPixels.coerceAtLeast(1)
        screenDensity = metrics.densityDpi
        imageReader = ImageReader.newInstance(screenWidth, screenHeight, PixelFormat.RGBA_8888, 2)

        mediaProjection?.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                stopSelf()
            }
        }, android.os.Handler(mainLooper))

        virtualDisplay = mediaProjection?.createVirtualDisplay(
            "CircleTrackerCapture", screenWidth, screenHeight, screenDensity,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader?.surface, null, null
        )

        running.set(true)
        worker = Thread { processFrames() }.also { it.start() }
    }

    private fun processFrames() {
        while (running.get()) {
            val image = imageReader?.acquireLatestImage()
            if (image == null) {
                try { Thread.sleep(15) } catch (_: InterruptedException) { break }
                continue
            }
            try {
                detectInImage(image)
            } catch (e: Exception) {
                e.printStackTrace()
            } finally {
                image.close()
            }
            try { Thread.sleep(15) } catch (_: InterruptedException) { break }
        }
    }

    private fun detectInImage(image: Image) {
        val plane = image.planes[0]
        val buffer = plane.buffer
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val rowPadding = rowStride - pixelStride * screenWidth
        val paddedWidth = screenWidth + rowPadding / pixelStride
        val bytes = ByteArray(buffer.remaining())
        buffer.get(bytes)

        val full = Mat(screenHeight, paddedWidth, CvType.CV_8UC4)
        full.put(0, 0, bytes)

        val rw = regionWidth.coerceIn(20, screenWidth)
        val rh = regionHeight.coerceIn(20, screenHeight)
        val rx = ((screenWidth - rw) / 2).coerceAtLeast(0)
        val ry = ((screenHeight - rh) / 2).coerceAtLeast(0)
        val roi = Mat(full, Rect(rx, ry, rw, rh))
        val hsv = Mat()
        val yellowMask = Mat()
        val gray = Mat()
        val edges = Mat()
        val hierarchy = Mat()
        val contours = ArrayList<MatOfPoint>()

        try {
            // 黄色領域をHSVで検出して解析対象から除外する
            Imgproc.cvtColor(roi, hsv, Imgproc.COLOR_RGBA2RGB)
            Imgproc.cvtColor(hsv, hsv, Imgproc.COLOR_RGB2HSV)
            Core.inRange(hsv, Scalar(18.0, 70.0, 70.0), Scalar(38.0, 255.0, 255.0), yellowMask)
            val nonYellow = Mat()
            Core.bitwise_not(yellowMask, yellowMask)
            Core.bitwise_and(roi, roi, nonYellow, yellowMask)

            Imgproc.cvtColor(nonYellow, gray, Imgproc.COLOR_RGBA2GRAY)
            Imgproc.GaussianBlur(gray, gray, Size(5.0, 5.0), 0.0)
            val threshold = sensitivity.coerceIn(1.0, 500.0)
            Imgproc.Canny(gray, edges, threshold, threshold * 2.0)
            Imgproc.findContours(edges, contours, hierarchy, Imgproc.RETR_LIST, Imgproc.CHAIN_APPROX_SIMPLE)

            var bestX = -1f
            var bestY = -1f
            var bestScore = 0.0
            for (contour in contours) {
                val points = MatOfPoint2f(*contour.toArray().map { Point(it.x, it.y) }.toTypedArray())
                try {
                    val center = Point()
                    val r = FloatArray(1)
                    Imgproc.minEnclosingCircle(points, center, r)
                    val radiusFound = r[0]
                    if (radiusFound in 10f..200f) {
                        val area = Imgproc.contourArea(contour)
                        val perimeter = Imgproc.arcLength(points, true)
                        if (perimeter > 0.0) {
                            val circularity = 4.0 * Math.PI * area / (perimeter * perimeter)
                            val score = circularity * radiusFound
                            if (score > bestScore) {
                                bestScore = score
                                bestX = rx + center.x.toFloat()
                                bestY = ry + center.y.toFloat()
                            }
                        }
                    }
                } finally {
                    points.release()
                }
            }

            if (bestX >= 0f && bestY >= 0f) {
                if (lastX >= 0f && lastY >= 0f) {
                    val distance = hypot((bestX - lastX).toDouble(), (bestY - lastY).toDouble())
                    if (distance < 100.0) {
                        lastX = lastX * 0.6f + bestX * 0.4f
                        lastY = lastY * 0.6f + bestY * 0.4f
                    } else {
                        lastX = bestX
                        lastY = bestY
                    }
                } else {
                    lastX = bestX
                    lastY = bestY
                }
            }
            overlayView.updatePosition(lastX, lastY)
            nonYellow.release()
        } finally {
            full.release()
            roi.release()
            hsv.release()
            yellowMask.release()
            gray.release()
            edges.release()
            hierarchy.release()
            contours.forEach { it.release() }
        }
    }

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            "CircleTrackerChannel", "Circle Tracker Service",
            NotificationManager.IMPORTANCE_LOW
        )
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    private fun createNotification(): Notification =
        Notification.Builder(this, "CircleTrackerChannel")
            .setContentTitle("CircleTracker 実行中")
            .setContentText("画面内の円を検出しています")
            .setSmallIcon(android.R.drawable.ic_menu_search)
            .build()

    override fun onDestroy() {
        running.set(false)
        worker?.interrupt()
        virtualDisplay?.release()
        imageReader?.close()
        mediaProjection?.stop()
        if (::overlayView.isInitialized) {
            windowManager.removeView(overlayView)
        }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
